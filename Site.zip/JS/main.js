const folderPlus = document.querySelector('.bx-folder-plus');
            folderPlus.addEventListener('click', () => {
              window.location.href = 'file:///C:/Users/Guillaume/Documents/ReparToutWebSite/devis.html';
            });
const laptop = document.getElementById('laptopIMG');
            laptop.addEventListener('click', () => {
              window.location.href = 'file:///C:/Users/Guillaume/Documents/ReparToutWebSite/laptop.html';
            });
const PC = document.getElementById("PcIMG");
            PC.addEventListener('click', () => {
              window.location.href = 'file:///C:/Users/Guillaume/Documents/ReparToutWebSite/PC.html';
            });
const smartphone = document.getElementById('smartphoneIMG');
            smartphone.addEventListener('click', () => {
              window.location.href = 'file:///C:/Users/Guillaume/Documents/ReparToutWebSite/Smartphone.html';
            });
        